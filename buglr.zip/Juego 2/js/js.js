	
	$.fx.interval = 100;
	
	
	(function($) {
		
		$.fn.bonus = function(bonusIndex, i, cantidad, delay){
			var cantidad = parseFloat(cantidad);
			var delay = parseFloat(delay);
			var delay = delay*800;
			
			$('.bonus').animate({scale: 0.1, opacity : 0}, delay).queue(function(){
				$('.multiplier h1').html(cantidad+'x');
				$('.icon').stop().css({ 'background-position' : '-164px '+bonusIndex[i]+'px' });	
				$(this).animate({opacity : 1, scale: 1.0}, 100);
				if(mute==false){
					if (isiPad){
						multiplierAudio.play();
					}else{
						if ($.browser.webkit || $.browser.mozilla || $.browser.opera) {
							multipliersound.playclip();
						}
					}
				}
				$(this).animate({opacity : 1, scale: 2.0}, 500);
				$(this).animate({opacity : 0, scale: 0.1}, 200);
				$(this).dequeue();
			});
		}
		
		$.fn.ScoreActual = function(Score, delay){
			var delay = delay*800;
			$('.score').html(Score);
			$('.score').css({scale: 0.5, opacity : 0});
			$('.score').animate({scale: 0.5, opacity : 0},delay,function(){
				if(mute==false){
					if(isiPad){
						scoreAudio.play();
					}else{
						if ($.browser.webkit || $.browser.mozilla || $.browser.opera) {
							scoresound.playclip();
						}
					}
				}
				$(this).animate({scale: 0.9, opacity : 1},500).queue(function(){
					$(this).animate({scale: 1, opacity : 0.8},300);
					$(this).animate({scale: 1.5, opacity : 0},200);
					$('.actual .html').html(Score);
					$(this).dequeue();
				});	
				$(this).css({scale: 0.5, opacity : 0});
				$('.boton').css({backgroundPosition : '0px 0'}).bind('click', function(){
					$(this).Rollar();
				});
			});
		}
				
		$.fn.Rollar = function(){
			if(mute==false){
				if(isiPad){
					clickAudio.play();
				}else{
					if ($.browser.webkit || $.browser.mozilla || $.browser.opera) {
						clicksound.playclip();
					}
				}
			}
			$(this).css({backgroundPosition : '-136px 0'});
			$(this).unbind('click');
			
			for(i=0; i < slots; i++){
				cantidad[i] = 0;
			}
			
			j = 0;
			
			for(i=0; i < rollers; i++){
				var randomnumber2 = Math.floor(Math.random()*(11));
				anteriorPosition[i] = String('0px '+(-1*randomnumber2*((slotsPosition[i]*alto)+alto))+'px');
				var randomnumber = Math.floor(Math.random()*(slots));
				slotsPosition[i] = randomnumber;
				cantidad[randomnumber]++;				
				var position = ((slotsPosition[i]*alto)+alto);
				
				newPosition[i] = String('0px '+position+'px');
			}
			
			
			$(".roller").each(function(){
				var indice = $('li').index(this);
				var k = 0;
				
				$(this).css({ backgroundPosition: anteriorPosition[indice] });
				
				var timeRandom = 100*(Math.floor(Math.random()*(25)));				
				
				$(this).animate({backgroundPosition : newPosition[indice]}, timeRandom, function(){
					if(mute==false){
						if(isiPad){
							stopAudio.play();
						}else{
							if ($.browser.webkit || $.browser.mozilla || $.browser.opera) {
								stopsound.playclip();
							}
						}
					}
					j++
					if(j == rollers ){
						
						$('.brillo').css({visibility : 'visible', opacity: 0});
						$('.brillo').animate({opacity: 0.5, scale: 1.2}, 500).queue(function(){
							$(this).animate({scale: 1}, 500);
							$(this).animate({opacity: 0}, 200);
							$(this).dequeue();
						});
						Score = 0;
						k = 0;
						for(i=	0; i<slots ; i++){
							if(cantidad[i]>1){
								bonusIndex[i] = (correccionBonus[i]*alto);
								var BonusdeIndice = (correccionPosicion[i+1]);
								
								var cantidades = cantidad[i];
						
								Score = Score+(BonusdeIndice*cantidades*multiplier);
								
								$(this).bonus(bonusIndex, i,cantidad[i],k);
								
								k++;
							}else{
								var BonusdeIndice = correccionPosicion[i+1];
								var cantidades = cantidad[i];
								
								Score = Score+(BonusdeIndice*cantidades);
							}							
							
							if(i == (slots-1)){
								$(this).ScoreActual(Score, k+1);
								scoreTotal = scoreTotal+Score;
								granTotal = granTotal+Score;
								$('.total .html').html(granTotal);
							}
						}
					}
				});
			});	
		}
	})(jQuery);
	
		var rollers = 5;
		var slots = 10;
		var alto = 160;
		var slotsPosition = Array(3,4,5,6,9);
		var timesCicles = Array();
		var newPosition = Array();
		var anteriorPosition = Array();
		var cantidad = Array();
		var correccionPosicion = Array(90, 80, 70, 60, 50, 40, 30, 20, 10, 100);
		var correccionBonus = Array(10, 1, 2,3,4,5,6,7,8,9);
		var bonusIndex = Array();
		var multiplier = 10;
		var Score = Number();
		var scoreTotal = Number();
		var granTotal = 120000;
		
		var clicksound = createsoundbite("sound/button.wav");
		var stopsound = createsoundbite("sound/spin.wav");
		var scoresound = createsoundbite("sound/win.wav");
		var multipliersound = createsoundbite("sound/multiplier.wav");
		
		var mute = false;
		
		if ($.browser.webkit) {
			var clickAudio = new Audio("sound/button.wav");
			var stopAudio = new Audio("sound/spin.wav");
			var scoreAudio = new Audio("sound/win.wav");
			var multiplierAudio = new Audio("sound/mulplier.wav");
 		}
		
		var isiPad = navigator.userAgent.match(/iPad/i) != null;
            	var ua = navigator.userAgent;
           	 var isiPad = /iPad/i.test(ua) || /iPhone OS 3_1_2/i.test(ua) || /iPhone OS 3_2_2/i.test(ua);
	
	$(document).ready(function(){
		$(".roller").each(function(){
			var indice = $('li').index(this);
			
			var randomnumber = Math.floor(Math.random()*(11));
			
			slotsPosition[indice] = randomnumber;
			$(this).css({ backgroundPosition: String('0px '+slotsPosition[indice]*alto+'px') });
		});
	
	
		$('.total .html').html(granTotal);		
		$('.bonus').css({scale: 0.1, opacity : 0})
		
		$('.boton').bind('click', function(){
			$(this).Rollar();
		});
		
		$('.mute').click(function(){
			if(mute==true){
				mute = false;
				$(this).css({backgroundPosition: "35px 0"});
			}else{
				mute = true;
				$(this).css({backgroundPosition: "0 0"});
			}
		})		
	});